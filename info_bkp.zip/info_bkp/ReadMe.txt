Ubuntu Linux VM Details.
=================================================
Ubuntu01
User:- ubuntu01 (Docker,Mysql,python,node and JDK is installed)
Password:- root
IP:- 192.168.56.102 --> Can be accessed via Putty

Commands
# sudo systemctl start docker
# sudo systemctl status docker
# sudo java -version
# python3 --version
# python3            --> Command to access python
# node -v
# mysql		     --> Command to access mysql and password is root	
**************************************************
Slave01 (python,node and JDK is installed)
User:- slave01
Password:- root
IP:- 192.168.56.104 --> Can be accessed via Putty
**************************************************
Slave02 (python,node and JDK is installed)
User:- slave02
Password:- root
IP:- 192.168.56.105 --> Can be accessed via Putty
=================================================

